import pandas as pd
import numpy as np
import streamlit as st
import pickle
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.neighbors import KNeighborsRegressor

# Load the dataset
dataset = pd.read_csv("Laptop_price.csv")

# Clean and ensure the correct data types for categorical columns
dataset['Condition'] = dataset['Condition'].str.strip().replace('', np.nan).astype(str)
dataset['Brand'] = dataset['Brand'].str.strip().replace('', np.nan).astype(str)

# Drop rows with NaN values if any exist
dataset.dropna(inplace=True)

# Check unique values in the categorical columns for debugging
print("Unique values in 'Brand':", dataset['Brand'].unique())
print("Unique values in 'Condition':", dataset['Condition'].unique())



# Split the dataset into features and target variable
#x = dataset.iloc[:, :-1].values
#y = dataset.iloc[:, -1].values

x = dataset.drop('Price', axis=1)  # Keep this as a DataFrame
y = dataset['Price'].values  # Target variable

print("Data types of the features:")
print(dataset.dtypes)


# Identify categorical and numerical features
categorical_features = ['Brand', 'Condition']
numerical_features = ['Processor_Speed', 'RAM_Size', 'Storage_Capacity', 'Screen_Size', 'Weight']

# Create the ColumnTransformer
ct = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), numerical_features),
        ('cat', OneHotEncoder(), categorical_features)
    ],
    remainder='drop'
)

# Apply the ColumnTransformer to the feature set
x = ct.fit_transform(x)

# Split the transformed dataset into training and testing sets
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=0)

# Train the Linear Regression model
linear_regressor = LinearRegression()
linear_regressor.fit(x_train, y_train)

# Train the K-Nearest Neighbors Regressor model
knn_regressor = KNeighborsRegressor(n_neighbors=5)
knn_regressor.fit(x_train, y_train)


# Save the trained models and the ColumnTransformer to .pkl files
with open("linear_model.pkl", "wb") as f:
    pickle.dump(linear_regressor, f)

with open("knn_model.pkl", "wb") as f:
    pickle.dump(knn_regressor, f)

with open("ct.pkl", "wb") as f:
    pickle.dump(ct, f)


# Function to encode a new sample and make predictions
def predict_new_sample(sample, ct, regressor):
    # Convert the new sample to a DataFrame before transforming
    sample_df = pd.DataFrame([sample], columns=['Brand', 'Processor_Speed', 'RAM_Size', 'Storage_Capacity', 'Screen_Size', 'Weight', 'Condition'])
    
    # Transform the new sample using the ColumnTransformer
    sample_encoded = np.array(ct.transform(sample_df))
    
    # Make a prediction using the trained regressor
    prediction = regressor.predict(sample_encoded)
    return prediction


# CSS for customizing the header
custom_header = '''
   <style>
    .stApp {
        background-color: #F5F5DC;  /* Darker beige/tan color */
    }
    h2 {
        color: #B03060; /* Darker pink/maroon color */
        font-family: 'Comic Sans MS', cursive;  /* Cursive font style */
        font-size: 40px;
    }
      label {
        color: black !important;  /* Force dropdown labels to be black */
        font-weight: bold;
        font-size: 18px;
    }
    /* Style for dropdown labels */
    /* Style for prediction output text */
    div.stMarkdown p {
        color: black !important;  /* Force prediction output text to be black */
        font-weight: bold;
        font-size: 22px;  /* Increase font size for output */
    }
    /* Style for markdown headings */
    h3 {
        color: #B03060 !important;  /* Force the "Prediction for the new sample" heading to be black */
        font-size: 24px;
        font-weight: bold;
    }

    </style>

'''
# Apply the custom CSS style
st.markdown(custom_header, unsafe_allow_html=True)

# User inputs for the new sample
st.write("## Laptop Price Prediction")

brand = st.selectbox("Brand", dataset.iloc[:, 0].unique())
weight = st.number_input("Weight (in kg)", min_value=0.0, format="%.2f")
ram = st.selectbox("RAM (in GB)", dataset.iloc[:,2].unique())
storage = st.selectbox("Storage (in GB)", dataset.iloc[:,3].unique())
screen_size = st.number_input("Screen Size (in inches)", min_value=0.0, format="%.2f")
cpu_speed = st.number_input("CPU Speed (in GHz)", min_value=0.0, format="%.2f")
condition = st.selectbox("Condition", dataset.iloc[:,6].unique())
new_sample = [brand, weight, ram, storage, screen_size, cpu_speed, condition]

if st.button("Predict"):
    # Make a prediction for the new sample using both models
    linear_prediction = predict_new_sample(new_sample, ct, linear_regressor)
    knn_prediction = predict_new_sample(new_sample, ct, knn_regressor)

    st.write(f"### Prediction for the new sample")
    st.write(f"**Linear Regression Prediction:** {linear_prediction[0]:,.2f}")
    st.write(f"**KNN Regression Prediction:** {knn_prediction[0]:,.2f}")
